# Personal Portfolio Website – ThiranX Project

A responsive full-stack personal portfolio built with:
- Frontend: HTML5, CSS3 and JavaScript
- Backend: Python Flask
- Database: SQLite

## Features
1. Responsive personal portfolio.
2. About, skills, projects and contact sections.
3. Project details are read from an SQLite database.
4. Add a project using the form; the data is saved in SQLite.
5. Delete a project.
6. Health-check endpoint at `/health`.

## Run locally

1. Install Python 3.10 or later.
2. Open a terminal in this project folder.
3. Create a virtual environment (recommended):

   Windows:
   `python -m venv venv`
   `venv\\Scripts\\activate`

   macOS/Linux:
   `python3 -m venv venv`
   `source venv/bin/activate`

4. Install dependencies:

   `pip install -r requirements.txt`

5. Start the application:

   `python app.py`

6. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`portfolio.db`) is created automatically on first run.

## Before submission
- Replace the email, GitHub and LinkedIn placeholders in `templates/index.html`.
- Check that your name, college and skills are correct.
- Add your own GitHub links to each project if available.
- Take screenshots of the home page, projects section and add-project form.
- Do not publish private information.

## Deployment
For a beginner-friendly deployment, use a Python hosting service that supports Flask. Set the start command to:

`gunicorn app:app`

Add `gunicorn` to `requirements.txt` before deployment. Note that some free hosting platforms use temporary filesystems; use persistent storage or a managed database if you need project data to remain permanently after redeployments.
