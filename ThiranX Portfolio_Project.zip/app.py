from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("portfolio.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                tech_stack TEXT NOT NULL,
                project_link TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        count = conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        if count == 0:
            conn.executemany("""
                INSERT INTO projects (title, description, tech_stack, project_link)
                VALUES (?, ?, ?, ?)
            """, [
                ("PlantCare AI", "A smart plant-care assistant concept that helps users understand plant health and watering needs.", "HTML, CSS, JavaScript", ""),
                ("Calculator App", "A simple calculator built with a clean interface and basic arithmetic operations.", "HTML, CSS, JavaScript", ""),
                ("Music Player", "A responsive music player interface with play, pause and track controls.", "HTML, CSS, JavaScript", "")
            ])

@app.route("/")
def home():
    with get_db() as conn:
        projects = conn.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()
    return render_template("index.html", projects=projects)

@app.route("/admin/add", methods=["POST"])
def add_project():
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    tech_stack = request.form.get("tech_stack", "").strip()
    project_link = request.form.get("project_link", "").strip()

    if not title or not description or not tech_stack:
        flash("Please fill in the title, description and technology fields.")
        return redirect(url_for("home"))

    with get_db() as conn:
        conn.execute("""
            INSERT INTO projects (title, description, tech_stack, project_link)
            VALUES (?, ?, ?, ?)
        """, (title, description, tech_stack, project_link))
    flash("Project added successfully!")
    return redirect(url_for("home") + "#projects")

@app.route("/admin/delete/<int:project_id>", methods=["POST"])
def delete_project(project_id):
    with get_db() as conn:
        conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    flash("Project deleted.")
    return redirect(url_for("home") + "#projects")

@app.route("/health")
def health():
    return {"status": "ok", "database": "connected"}

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
